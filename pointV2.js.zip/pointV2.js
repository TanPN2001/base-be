// // const { GLOBAL_CONSTANTS } = require('../configs/constants/global.constant');

// const RATE = {
//   APP_NAME: 'PointTeleChatBot',
//   VERSION: '1.0.0',
//   RATE: {
//     F1: {
//       unit: 1000, // đơn vị
//       point: 80, // rate nhận về
//       type: {
//         NORMAL: 1000, // chiết khấu cho user normal
//         VIP: 850, // chiết khấu cho user vip
//       },
//     },
//     F2: {
//       unit: 1000,
//       point: 80,
//       type: {
//         NORMAL: 1000,
//         VIP: 850,
//       },
//     },
//     F3: {
//       unit: 1000,
//       point: 80,
//       type: {
//         NORMAL: 23000,
//         VIP: 22000,
//       },
//     },
//     F4a: {
//       unit: 1000,
//       point: 10,
//       type: {
//         NORMAL: 1000,
//         VIP: 800,
//       },
//     },
//     F4b: {
//       unit: 1000,
//       point: 40,
//       type: {
//         NORMAL: 1000,
//         VIP: 800,
//       },
//     },
//     F4c: {
//       unit: 1000,
//       point: 100,
//       type: {
//         NORMAL: 1000,
//         VIP: 800,
//       },
//     },
//     F5: {
//       unit: 1000,
//       point: 400,
//       type: {
//         NORMAL: 1000,
//         VIP: 800,
//       },
//     },
//   },
//   DURATION_CACHE: 5,
// };

// /**
//  * Remove Vietnamese characters form string
//  * @param {String} str
//  * @returns {String} string
//  */
// function normalizeVietnameseString(str) {
//   str = str.toLowerCase();
//   str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, 'a');
//   str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, 'e');
//   str = str.replace(/ì|í|ị|ỉ|ĩ/g, 'i');
//   str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, 'o');
//   str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, 'u');
//   str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, 'y');
//   str = str.replace(/đ/g, 'd');
//   return str;
// }

// /**
//  * escapeRegExp
//  * @param {String} text
//  * @returns
//  */
// function escapeRegExp(text) {
//   return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
// }

// /**
//  *
//  * @param {String} input
//  * @returns
//  */
// function replaceMultipleGroups(input, replacements) {
//   for (const { keywords, value } of replacements) {
//     const escapedKeywords = keywords.map(escapeRegExp);
//     const regex = new RegExp(escapedKeywords.join('|'), 'gi');
//     input = input.replace(regex, value);
//   }

//   return input;
// }

// /**
//  * Nén nhóm F1, F2, F3, F5
//  * @param {String} input
//  * @returns
//  */
// const extractFxGroups = input => {
//   input = input
//     .replace(/_/g, ' ')
//     .replace(/x\s*_?\s*(\d+)/g, 'x$1')
//     .replace(/\s+/g, ' ')
//     .trim();

//   const segments = input.split('|');
//   const result = {};
//   const validFlags = ['F1', 'F2', 'F3', 'F5'];
//   let currentFlag = null;

//   for (let segment of segments) {
//     segment = segment.trim();
//     if (!segment) continue;

//     const matchFlag = segment.match(/^(F\d)/);
//     if (matchFlag) {
//       const newFlag = matchFlag[1];
//       segment = segment.replace(newFlag, '').trim();

//       if (validFlags.includes(newFlag)) {
//         currentFlag = newFlag;
//       } else {
//         // Gặp F4 hoặc F khác không hợp lệ thì reset flag
//         currentFlag = null;
//       }
//     }

//     if (!currentFlag) continue;

//     const xMatch = segment.match(/x(\d+)/);
//     if (!xMatch) continue;

//     const groupKey = 'x' + xMatch[1];
//     const numbersPart = segment.split(/x\d+/)[0].trim();
//     const numbers = numbersPart
//       .split(/[\s_]+/)
//       .map(Number)
//       .filter(n => !isNaN(n));

//     if (!result[currentFlag]) result[currentFlag] = {};
//     if (!result[currentFlag][groupKey]) result[currentFlag][groupKey] = [];

//     const splitNumbers = [];
//     numbers.forEach(num => {
//       const numStr = num.toString();
//       if (numStr.length === 3) {
//         const ab = numStr.substring(0, 2);
//         const bc = numStr.substring(1, 3);
//         splitNumbers.push(ab, bc);
//       } else {
//         splitNumbers.push(num);
//       }
//     });
//     result[currentFlag][groupKey].push(...splitNumbers);
//   }

//   return result;
// };

// /**
//  * Nén nhóm dành riêng cho F4
//  * @param {String} input
//  * @returns
//  */
// function extractF4Groups(input) {
//   const result = {};
//   const f4Pattern = /F4([^F]*)/g;
//   let match;

//   while ((match = f4Pattern.exec(input)) !== null) {
//     const f4Content = match[1];
//     const groupPattern = /([0-9\s,;.\-:_]+?)x\s?(\d+)\s?\|/g;
//     let groupMatch;

//     while ((groupMatch = groupPattern.exec(f4Content)) !== null) {
//       const numbersStr = groupMatch[1];
//       const xValue = 'x' + groupMatch[2];

//       // Tách thành từng bộ số
//       const rawNumbers = numbersStr
//         .trim()
//         .split(/[,\.;:\-_]/) // chia bộ
//         .map(s => s.trim())
//         .filter(s => s.length > 0);

//       // Gom nhóm các bộ số liên tiếp (giữa các dấu cách)
//       let tempGroup = [];
//       const finalGroups = [];
//       for (let part of rawNumbers) {
//         const nums = part
//           .split(/\s+/)
//           .map(n => parseInt(n))
//           .filter(n => !isNaN(n));

//         if (nums.length > 0) {
//           finalGroups.push(nums);
//         }
//       }

//       if (!result[xValue]) {
//         result[xValue] = [];
//       }
//       result[xValue].push(...finalGroups);
//     }
//   }

//   return result;
// }

// // Nhóm thay thế
// const f4Replacements = [
//   { keywords: ['f1', 'de'], value: 'F1' },
//   { keywords: ['f2', 'giainhat', 'giai nhat'], value: 'F2' },
//   { keywords: ['f3', 'lo'], value: 'F3' },
//   { keywords: ['xien'], value: 'F4' },
//   { keywords: ['f5', '3 cang', '3cang', 'ba cang', 'bacang'], value: 'F5' },
//   { keywords: ['nghin', 'n', 'k', 'diem', 'd'], value: '|' },
// ];
// // Nhóm thay thế
// const fxReplacements = [
//   { keywords: ['f1', 'de'], value: 'F1' },
//   { keywords: ['f2', 'giainhat', 'giai nhat'], value: 'F2' },
//   { keywords: ['f3', 'lo'], value: 'F3' },
//   { keywords: ['xien'], value: 'F4' },
//   { keywords: ['f5', '3 cang', '3cang', 'ba cang', 'bacang'], value: 'F5' },
//   { keywords: ['.', ',', ':', ';', '-', '_', '&', '|', '/', ' '], value: '_' },
//   { keywords: ['nghin', 'n', 'k', 'diem', 'd'], value: '|' },
// ];

// const extractGroup = input => {
//   let rawInput = input;
//   let fxInput = replaceMultipleGroups(input, fxReplacements);
//   let resultFx = extractFxGroups(fxInput);

//   let f4Input = replaceMultipleGroups(rawInput, f4Replacements);
//   let resultF4 = extractF4Groups(f4Input);

//   let result = resultFx;

//   for (let key in resultF4) {
//     for (let subResult of resultF4[key]) {
//       let pointType =
//         subResult.length == 2
//           ? 'F4a'
//           : subResult.length == 3
//             ? 'F4b'
//             : subResult.length == 4
//               ? 'F4c'
//               : null;
//       //   pointType = null;
//       if (!pointType) {
//         throw new Error('ERROR');
//       }
//       if (!result[pointType]) {
//         result[pointType] = {};
//       }
//       if (!result[pointType][key]) {
//         result[pointType][key] = [];
//       }
//       result[pointType][key].push(subResult);
//     }
//   }

//   return result;
// };

// /**
//  * Trừ điểm theo rate
//  * TO_DO: transaction
//  * @param {Number} point
//  * @param {User} user
//  * @param {String} pointType
//  * @returns {Number|String} - Trả về số điểm đã trừ hoặc thông báo lỗi nếu không đủ điểm
//  */
// const calculateTopUpPoint = (point, user, pointType) => {
//   let userType = user?.type; // loại tài khoản
//   let totalPoint = 0;
//   // pointType = pointType.toUpperCase();
//   let rate = RATE[pointType]; // tỉ lệ điểm nhận được
//   let subPoint = rate?.type[userType]; // điểm trừ
//   if (!subPoint || !rate) {
//     return -2;
//   }

//   subPoint = point * subPoint;
//   totalPoint += subPoint;

//   return totalPoint;
// };

// /**
//  *
//  * @param {JSON} json
//  */
// const formatResult = (json, user) => {
//   let totalPoint = 0;
//   let message = '';
//   for (const key in json) {
//     message += `\n👑 Loại: ${key}`;
//     const subObj = json[key];
//     if (['F1', 'F2', 'F3', 'F5'].includes(key)) {
//       let subTotalPoint = 0;
//       let subMessage = '';
//       for (const subKey in subObj) {
//         let keyValue = parseInt(subKey.substring(1));
//         for (let point of subObj[subKey]) {
//           subMessage = subMessage + (subMessage.length ? ' ' : '') + `${point}`;
//           let subResult = calculateTopUpPoint(keyValue, user, key);
//           if (subResult < 0) {
//             // isSuccess = 0;
//           } else {
//             subTotalPoint += subResult;
//           }
//         }
//         // message += `\n📍 ${subMessage} x ${keyValue * subObj[subKey].length} c`;
//         message += `\n📍 ${subMessage} x ${keyValue} c`;
//         subMessage = '';
//       }
//       message += `\n⌛ Tổng: ${subTotalPoint}\n`;
//       totalPoint += subTotalPoint;
//       subTotalPoint = 0;
//     } else if (['F4a', 'F4b', 'F4c'].includes(key)) {
//       let subTotalPoint = 0;
//       let subMessage = '';
//       for (const subKey in subObj) {
//         let keyValue = parseInt(subKey.substring(1));
//         let subResult = calculateTopUpPoint(keyValue, user, key);
//         for (let points of subObj[subKey]) {
//           if (key == 'F4a' && points.length == 2) {
//             subMessage += `[${points[0]} ${points[1]}] `;
//             subTotalPoint += subResult;
//           } else if (key == 'F4b' && points.length == 3) {
//             subMessage += `[${points[0]} ${points[1]} ${points[2]}] `;
//             subTotalPoint += subResult;
//           } else if (key == 'F4c' && points.length == 4) {
//             subMessage += `[${points[0]} ${points[1]} ${points[2]} ${points[3]}] `;
//             subTotalPoint += subResult;
//           }
//         }
//         // message += `\n📍 ${subMessage} x ${subResult * subObj[subKey].length} c`;
//         message += `\n📍 ${subMessage} x ${subResult} c`;
//         subMessage = '';
//       }
//       let formatSubTotalPoint = new Intl.NumberFormat('vi-VN').format(
//         subTotalPoint,
//       );
//       message += `\n⌛ Tổng: ${formatSubTotalPoint}\n`;
//       totalPoint += subTotalPoint;
//       subTotalPoint = 0;
//     }
//   }
//   let formatTotalPoint = new Intl.NumberFormat('vi-VN').format(totalPoint);
//   message += `\n⁉️ Tổng: ${formatTotalPoint}`;
//   // console.log(message);

//   return {
//     totalPoint,
//     message,
//   };
// };

// module.exports = {
//   extractGroup,
//   formatResult,
//   normalizeVietnameseString,
// };

// // const groups = extractGroup(input);
// // // console.log(JSON.stringify(groups));
// // const user = {
// //   type: 'NORMAL',
// //   point: 1000000,
// // };
// // const json = formatResult(groups, user);

// const { GLOBAL_CONSTANTS } = require('../configs/constants/global.constant');

// const RATE = {
//   APP_NAME: 'PointTeleChatBot',
//   VERSION: '1.0.0',
//   RATE: {
//     F1: {
//       unit: 1000, // đơn vị
//       point: 80, // rate nhận về
//       type: {
//         NORMAL: 1000, // chiết khấu cho user normal
//         VIP: 850, // chiết khấu cho user vip
//       },
//     },
//     F2: {
//       unit: 1000,
//       point: 80,
//       type: {
//         NORMAL: 1000,
//         VIP: 850,
//       },
//     },
//     F3: {
//       unit: 1000,
//       point: 80,
//       type: {
//         NORMAL: 23000,
//         VIP: 22000,
//       },
//     },
//     F4a: {
//       unit: 1000,
//       point: 10,
//       type: {
//         NORMAL: 1000,
//         VIP: 800,
//       },
//     },
//     F4b: {
//       unit: 1000,
//       point: 40,
//       type: {
//         NORMAL: 1000,
//         VIP: 800,
//       },
//     },
//     F4c: {
//       unit: 1000,
//       point: 100,
//       type: {
//         NORMAL: 1000,
//         VIP: 800,
//       },
//     },
//     F5: {
//       unit: 1000,
//       point: 400,
//       type: {
//         NORMAL: 1000,
//         VIP: 800,
//       },
//     },
//   },
//   DURATION_CACHE: 5,
// };

const { GLOBAL_CONSTANTS } = require('../configs/constants/global.constant');

/**
 * Remove Vietnamese characters form string
 * @param {String} str
 * @returns {String} string
 */
function normalizeVietnameseString(str) {
  str = str.toLowerCase();
  str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, 'a');
  str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, 'e');
  str = str.replace(/ì|í|ị|ỉ|ĩ/g, 'i');
  str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, 'o');
  str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, 'u');
  str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, 'y');
  str = str.replace(/đ/g, 'd');
  return str;
}

/**
 * escapeRegExp
 * @param {String} text
 * @returns
 */
function escapeRegExp(text) {
  return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
  // return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // replacement with excludeWords
}

// /**
//  *
//  * @param {String} input
//  * @returns
//  */
function replaceMultipleGroups(
  input,
  replacements,
  excludeWords = ['nghin', 'tong', 'chin', 'bon', 'chan', 'kep', 'dau', 'dit'],
) {
  for (const { keywords, value } of replacements) {
    for (let keyword of keywords) {
      const escapedKeyword = escapeRegExpV1(keyword);

      let replacementChars = ['n', 'k', 'd'];
      if (replacementChars.includes(keyword)) {
        // Tìm tất cả từ chứa keyword
        input = input.replace(
          new RegExp(escapedKeyword, 'gi'),
          (match, offset, str) => {
            // Lấy phần từ chứa ký tự đang xét (ví dụ: x10n)
            const wordStart = Math.max(0, offset - 10); // lấy đoạn phía trước
            const wordEnd = Math.min(str.length, offset + 10); // lấy đoạn phía sau
            const context = str.substring(wordStart, wordEnd).toLowerCase();

            // Nếu context chứa một từ bị loại trừ → không thay thế
            if (excludeWords.some(ex => context.includes(ex))) {
              return match;
            }

            return value;
          },
        );
      } else {
        const regex = new RegExp(escapedKeyword, 'gi');
        input = input.replace(regex, value);
      }
    }
  }

  return input;
}

function escapeRegExpV1(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function expandMultiHeadTails(input) {
  const patterns = ['dau', 'dit', 'tong'];

  for (let key of patterns) {
    // Regex sẽ match "dau1 2", "dau 1,2", "dau:1 2", v.v.
    const regex = new RegExp(`${key}[\\s:]*((?:\\d+[\\s,]*)+)`, 'gi');

    input = input.replace(regex, (match, numbersGroup) => {
      const numbers = numbersGroup
        .split(/[\s,]+/) // tách bởi khoảng trắng hoặc dấu phẩy
        .filter(Boolean); // loại bỏ rỗng

      const expanded = numbers.map(n => `${key}${n}`).join(' ');
      return expanded;
    });
  }

  return input;
}

// function replaceMultipleGroups(input, replacements) {
//     for (const { keywords, value } of replacements) {
//         const escapedKeywords = keywords.map(escapeRegExp);
//         const regex = new RegExp(escapedKeywords.join('|'), 'gi');
//         input = input.replace(regex, value);
//     }

//     return input;
// }

/**
 * Nén nhóm F1, F2, F3, F5
 * @param {String} input
 * @returns
 */
const extractFxGroups = input => {
  input = input
    .replace(/_/g, ' ')
    .replace(/x\s*_?\s*(\d+)/g, 'x$1')
    .replace(/\s+/g, ' ')
    .trim();

  const segments = input.split('|');
  const result = {};
  const validFlags = ['F1', 'F2', 'F3', 'F5'];
  let currentFlag = null;

  for (let segment of segments) {
    segment = segment.trim();
    if (!segment) continue;

    const matchFlag = segment.match(/^(F\d)/);
    if (matchFlag) {
      const newFlag = matchFlag[1];
      segment = segment.replace(newFlag, '').trim();

      if (validFlags.includes(newFlag)) {
        currentFlag = newFlag;
      } else {
        // Gặp F4 hoặc F khác không hợp lệ thì reset flag
        currentFlag = null;
      }
    }

    if (!currentFlag) continue;

    const xMatch = segment.match(/x(\d+)/);
    if (!xMatch) continue;

    const groupKey = 'x' + xMatch[1];
    const numbersPart = segment.split(/x\d+/)[0].trim();

    // Áp dụng thay thế đặc biệt nếu là F1 hoặc F2
    // numbersPart = applySpecialReplacements(numbersPart, currentFlag);

    const numbers = applySpecialReplacements(numbersPart, currentFlag)
      .split(/[\s_]+/)
      .map(Number)
      .filter(n => !isNaN(n));

    if (!result[currentFlag]) result[currentFlag] = {};
    if (!result[currentFlag][groupKey]) result[currentFlag][groupKey] = [];

    const splitNumbers = [];
    numbers.forEach(num => {
      const numStr = num.toString();
      if (numStr.length === 3) {
        const ab = numStr.substring(0, 2);
        const bc = numStr.substring(1, 3);
        splitNumbers.push(ab, bc);
      } else {
        splitNumbers.push(num);
      }
    });
    result[currentFlag][groupKey].push(...splitNumbers);
  }

  return result;
};

/**
 * Nén nhóm dành riêng cho F4
 * @param {String} input
 * @returns
 */
function extractF4Groups(input) {
  const result = {};
  const f4Pattern = /F4([^F]*)/g;
  let match;

  while ((match = f4Pattern.exec(input)) !== null) {
    const f4Content = match[1];
    const groupPattern = /([0-9\s,;.\-:_]+?)x\s?(\d+)\s?\|/g;
    let groupMatch;

    while ((groupMatch = groupPattern.exec(f4Content)) !== null) {
      const numbersStr = groupMatch[1];
      const xValue = 'x' + groupMatch[2];

      // Tách thành từng bộ số
      const rawNumbers = numbersStr
        .trim()
        .split(/[,\.;:\-_]/) // chia bộ
        .map(s => s.trim())
        .filter(s => s.length > 0);

      // Gom nhóm các bộ số liên tiếp (giữa các dấu cách)
      let tempGroup = [];
      const finalGroups = [];
      for (let part of rawNumbers) {
        const nums = part
          .split(/\s+/)
          .map(n => parseInt(n))
          .filter(n => !isNaN(n));

        if (nums.length > 0) {
          finalGroups.push(nums);
        }
      }

      if (!result[xValue]) {
        result[xValue] = [];
      }
      result[xValue].push(...finalGroups);
    }
  }

  return result;
}

// // Nhóm thay thế
// const f4Replacements = [
//   { keywords: ['f1', 'de'], value: 'F1' },
//   { keywords: ['f2', 'giainhat', 'giai nhat'], value: 'F2' },
//   { keywords: ['f3', 'lo'], value: 'F3' },
//   { keywords: ['xien'], value: 'F4' },
//   { keywords: ['f5', '3 cang', '3cang', 'ba cang', 'bacang'], value: 'F5' },
//   { keywords: ['nghin', 'n', 'k', 'diem', 'd'], value: '|' },
// ];

// Nhóm thay thế
const f4Replacements = [
  { keywords: ['f1', 'de'], value: 'F1' }, // d: 1 số
  { keywords: ['f2', 'giainhat', 'giai nhat'], value: 'F2' }, // gn: 1 số
  { keywords: ['f3', 'lo'], value: 'F3' }, // l: 1 số
  { keywords: ['f4', 'xien'], value: 'F4' }, // xien: n số
  { keywords: ['f5', '3 cang', '3cang', 'ba cang', 'bacang'], value: 'F5' }, // 3c: n số
  { keywords: ['nghin', 'n', 'k', 'diem', 'd'], value: '|' },
];
// Nhóm thay thế
const fxReplacements = [
  { keywords: ['f1', 'de'], value: 'F1' }, // d: 1 số
  { keywords: ['f2', 'giainhat', 'giai nhat'], value: 'F2' }, // gn: 1 số
  { keywords: ['f3', 'lo'], value: 'F3' }, // l: 1 số
  { keywords: ['f4', 'xien', 'lo xien', 'loxien'], value: 'F4' }, // xien: n số
  {
    keywords: [
      'f5',
      '3 cang',
      '3cang',
      'ba cang',
      'bacang',
      'de ba cang',
      'debacang',
      'de 3 cang',
      'de3cang',
      'de 3cang',
      'de bacang',
      'de3 cang',
      'deba cang',
    ],
    value: 'F5',
  }, // 3c: n số
  { keywords: ['.', ',', ':', ';', '-', '_', '&', '|', '/', ' '], value: '_' },
  { keywords: ['nghin', 'n', 'k', 'diem', 'd'], value: '|' },
];

const specialTypeReplacements = [
  { keywords: ['kepbang', 'kep bang'], value: '00 11 22 33 44 55 66 77 88 99' },
  { keywords: ['keplech', 'kep lech'], value: '05 50 16 61 27 72 38 83 49 94' },
  {
    keywords: ['chanchan', 'chan chan'],
    value:
      '00 02 04 06 08 20 22 24 26 28 40 42 44 46 48 60 62 64 66 68 80 82 84 86 88',
  },
  {
    keywords: ['chanle', 'chan le'],
    value:
      '01 03 05 07 09 21 23 25 27 29 41 43 45 47 49 61 63 65 67 69 81 83 85 87 89',
  },
  {
    keywords: ['lechan', 'le chan'],
    value:
      '10 12 14 16 18 30 32 34 36 38 50 52 54 56 58 70 72 74 76 78 90 92 94 96 98',
  },
  {
    keywords: ['lele', 'le le'],
    value:
      '11 13 15 17 19 31 33 35 37 39 51 53 55 57 59 71 73 75 77 79 91 93 95 97 99',
  },
  { keywords: ['tong 0', 'tong0'], value: '00 19 28 37 46 55 64 73 82 91' },
  { keywords: ['tong 1', 'tong1'], value: '01 10 29 38 47 56 65 74 83 92' },
  { keywords: ['tong 2', 'tong2'], value: '02 11 20 39 48 57 66 75 84 93' },
  { keywords: ['tong 3', 'tong3'], value: '03 12 21 30 49 58 67 76 85 94' },
  { keywords: ['tong 4', 'tong4'], value: '04 13 22 31 40 59 68 77 86 95' },
  { keywords: ['tong 5', 'tong5'], value: '05 14 23 32 41 50 69 78 87 96' },
  { keywords: ['tong 6', 'tong6'], value: '06 15 24 33 42 51 60 79 88 97' },
  { keywords: ['tong 7', 'tong7'], value: '07 16 25 34 43 52 61 70 89 98' },
  { keywords: ['tong 8', 'tong8'], value: '08 17 26 35 44 53 62 71 80 99' },
  { keywords: ['tong 9', 'tong9'], value: '09 18 27 36 45 54 63 72 81 90' },

  { keywords: ['dau0', 'dau 0'], value: '00 01 02 03 04 05 06 07 08 09' },
  { keywords: ['dau1', 'dau 1'], value: '10 11 12 13 14 15 16 17 18 19' },
  { keywords: ['dau2', 'dau 2'], value: '20 21 22 23 24 25 26 27 28 29' },
  { keywords: ['dau3', 'dau 3'], value: '30 31 32 33 34 35 36 37 38 39' },
  { keywords: ['dau4', 'dau 4'], value: '40 41 42 43 44 45 46 47 48 49' },
  { keywords: ['dau5', 'dau 5'], value: '50  51 52 53 54 55 56 57 58 59' },
  { keywords: ['dau6', 'dau 6'], value: '60 61 62 63 64 65 66 67 68 69' },
  { keywords: ['dau7', 'dau 7'], value: '70 71 72 73 74 75 76 77 78 79' },
  { keywords: ['dau8', 'dau 8'], value: '80 81 82 83 84 85 86 87 88 89' },
  { keywords: ['dau9', 'dau 9'], value: '90 91 92 93 94 95 96 97 98 99' },

  { keywords: ['dit0', 'dit 0'], value: '00 10 20 30 40 50 60 70 80 90' },
  { keywords: ['dit1', 'dit 1'], value: '01 11 21 31 41 51 61 71 81 91' },
  { keywords: ['dit2', 'dit 2'], value: '02 12 22 32 42 52 62 72 82 92' },
  { keywords: ['dit3', 'dit 3'], value: '03 13 23 33 43 53 63 73 83 93' },
  { keywords: ['dit4', 'dit 4'], value: '04 14 24 34 44 54 64 74 84 94' },
  { keywords: ['dit5', 'dit 5'], value: '05 15 25 35 45 55 65 75 85 95' },
  { keywords: ['dit6', 'dit 6'], value: '06 16 26 36 46 56 66 76 86 96' },
  { keywords: ['dit7', 'dit 7'], value: '07 17 27 37 47 57 67 77 87 97' },
  { keywords: ['dit8', 'dit 8'], value: '08 18 28 38 48 58 68 78 88 98' },
  { keywords: ['dit9', 'dit 9'], value: '09 19 29 39 49 59 69 79 89 99' },
];

const applySpecialReplacements = (text, flag) => {
  if (flag === 'F1' || flag === 'F2') {
    // return replaceMultipleGroups(text, specialTypeReplacements);
    const expandedText = expandMultiHeadTails(text); // ✅ thêm bước mở rộng
    return replaceMultipleGroups(expandedText, specialTypeReplacements);
  }
  return text;
};

const extractGroup = input => {
  let rawInput = input;
  let fxInput = replaceMultipleGroups(input, fxReplacements);
  let resultFx = extractFxGroups(fxInput);

  let f4Input = replaceMultipleGroups(rawInput, f4Replacements);
  let resultF4 = extractF4Groups(f4Input);

  let result = resultFx;

  for (let key in resultF4) {
    for (let subResult of resultF4[key]) {
      let pointType =
        subResult.length == 2
          ? 'F4a'
          : subResult.length == 3
            ? 'F4b'
            : subResult.length == 4
              ? 'F4c'
              : null;
      //   pointType = null;
      if (!pointType) {
        throw new Error('ERROR');
      }
      if (!result[pointType]) {
        result[pointType] = {};
      }
      if (!result[pointType][key]) {
        result[pointType][key] = [];
      }
      result[pointType][key].push(subResult);
    }
  }

  return result;
};

/**
 * Trừ điểm theo rate
 * TO_DO: transaction
 * @param {Number} point
 * @param {User} user
 * @param {String} pointType
 * @returns {Number|String} - Trả về số điểm đã trừ hoặc thông báo lỗi nếu không đủ điểm
 */
const calculateTopUpPoint = (point, user, pointType) => {
  let userType = user?.type; // loại tài khoản
  let totalPoint = 0;
  // pointType = pointType.toUpperCase();
  let rate = GLOBAL_CONSTANTS.RATE[pointType]; // tỉ lệ điểm nhận được
  let subPoint = rate?.type[userType]; // điểm trừ
  if (!subPoint || !rate) {
    return -2;
  }

  subPoint = point * subPoint;
  totalPoint += subPoint;

  return totalPoint;
};

/**
 *
 * @param {JSON} json
 */
const formatResult = (json, user) => {
  let totalPoint = 0;
  let message = '';
  for (const key in json) {
    message += `\n👑 Loại: ${key}`;
    const subObj = json[key];
    if (['F1', 'F2', 'F3', 'F5'].includes(key)) {
      let subTotalPoint = 0;
      let subMessage = '';
      for (const subKey in subObj) {
        let keyValue = parseInt(subKey.substring(1));
        for (let point of subObj[subKey]) {
          point = point.toString();
          point = point.length == 1 ? `0${point}` : point; // đảm bảo số có 2 chữ số
          subMessage = subMessage + (subMessage.length ? ' ' : '') + `${point}`;
          let subResult = calculateTopUpPoint(keyValue, user, key);
          if (subResult < 0) {
            // isSuccess = 0;
          } else {
            subTotalPoint += subResult;
          }
        }
        // message += `\n📍 ${subMessage} x ${keyValue * subObj[subKey].length} n`;
        message += `\n📍 ${subMessage} x ${keyValue} n`;
        subMessage = '';
      }
      let formatSubTotalPoint = new Intl.NumberFormat('vi-VN').format(
        subTotalPoint,
      );
      message += `\n⌛ Tổng: ${formatSubTotalPoint}\n`;
      totalPoint += subTotalPoint;
      subTotalPoint = 0;
    } else if (['F4a', 'F4b', 'F4c'].includes(key)) {
      let subTotalPoint = 0;
      let subMessage = '';
      for (const subKey in subObj) {
        let keyValue = parseInt(subKey.substring(1));
        let subResult = calculateTopUpPoint(keyValue, user, key);
        for (let points of subObj[subKey]) {
          if (key == 'F4a' && points.length == 2) {
            points[0] = points[0].toString();
            points[0] = points[0].length == 1 ? `0${points[0]}` : points[0];
            points[1] = points[1].toString();
            points[1] = points[1].length == 1 ? `0${points[1]}` : points[1];
            subMessage += `[${points[0]} ${points[1]}] `;
            subTotalPoint += subResult;
          } else if (key == 'F4b' && points.length == 3) {
            points[0] = points[0].toString();
            points[0] = points[0].length == 1 ? `0${points[0]}` : points[0];
            points[1] = points[1].toString();
            points[1] = points[1].length == 1 ? `0${points[1]}` : points[1];
            points[2] = points[2].toString();
            points[2] = points[2].length == 1 ? `0${points[2]}` : points[2];
            subMessage += `[${points[0]} ${points[1]} ${points[2]}] `;
            subTotalPoint += subResult;
          } else if (key == 'F4c' && points.length == 4) {
            points[0] = points[0].toString();
            points[0] = points[0].length == 1 ? `0${points[0]}` : points[0];
            points[1] = points[1].toString();
            points[1] = points[1].length == 1 ? `0${points[1]}` : points[1];
            points[2] = points[2].toString();
            points[2] = points[2].length == 1 ? `0${points[2]}` : points[2];
            points[3] = points[3].toString();
            points[3] = points[3].length == 1 ? `0${points[3]}` : points[3];
            subMessage += `[${points[0]} ${points[1]} ${points[2]} ${points[3]}] `;
            subTotalPoint += subResult;
          }
        }
        // message += `\n📍 ${subMessage} x ${subResult * subObj[subKey].length} c`;
        message += `\n📍 ${subMessage} x ${subResult} n`;
        subMessage = '';
      }
      let formatSubTotalPoint = new Intl.NumberFormat('vi-VN').format(
        subTotalPoint,
      );
      message += `\n⌛ Tổng: ${formatSubTotalPoint}\n`;
      totalPoint += subTotalPoint;
      subTotalPoint = 0;
    }
  }
  let formatTotalPoint = new Intl.NumberFormat('vi-VN').format(totalPoint);
  message += `\n⁉️ Tổng: ${formatTotalPoint}`;
  // console.log(message);

  return {
    totalPoint,
    message,
  };
};

module.exports = {
  extractGroup,
  formatResult,
  normalizeVietnameseString,
};

let input = 'de dau1,2 x10n';
const groups = extractGroup(input);

const user = {
  type: 'NORMAL',
  point: 1000000,
};
const json = formatResult(groups, user);

console.log(groups);
console.log(JSON.stringify(json, null, 2));
