const express = require('express');
const app = express();
require('dotenv').config();
let { port } = require('./config/redis.config');
const { redisClient } = require('./service/redis');

app.post('/write', async (req, res) => {
	try {
		console.log('Write to redis');
		await redisClient.set(req?.body?.key, JSON.stringify(req?.body?.value));
		res.json({ success: true });
	} catch (error) {
		console.log('create ERROR: ', error);
		res.json({ success: false, message: error?.stack || error?.message });
	}
});

app.get('/read', async (req, res) => {
	try {
		console.log('Read from redis');
		const result = await redisClient.get(req?.query?.key);
		console.log(result);
		res.json({ success: true, data: result });
	} catch (error) {
		console.log('read ERROR: ', error);
		res.json({ success: false, message: error?.stack || error?.message });
	}
});

port = port || 3000; // Default to 3000 if not set in config
app.listen(port, () => {
	console.log(`Server running on port ${port}`);
});
