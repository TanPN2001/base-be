const { Redis } = require('ioredis');
const config = require('../config/redis.config');

// console.log(JSON.stringify(config, null, 2));

const redisClient = new Redis(
	{
		sentinels: config.redisSentinels.sentinels,
		name: config.redisSentinels.name,
		showFriendlyErrorStack: true,
		db: config.redisSentinels.redisDB,
	},
	{ natMap: config.redisSentinels.natMap }
);

redisClient.on('connect', () => {
	console.info('Connect Redis successfully');
});

redisClient.on('error', (err) => {
	console.error('Redis client error', err);
});

module.exports = { redisClient };
