const serverConfig = {
  port: parseInt(process.env.PORT || 5000),
}

module.exports = serverConfig;